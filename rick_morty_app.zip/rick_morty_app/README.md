# rick_morty_app

A new Flutter project.
