package pe.edu.upc.rick_morty_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
