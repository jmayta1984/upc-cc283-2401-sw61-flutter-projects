class SuperHero {
  final String name;
  final String fullName;
  final String image;

  const SuperHero({
    required this.name,
    required this.fullName,
    required this.image,
  });

  SuperHero.fromJson(Map<String, dynamic> map)
      : name = map["name"],
        fullName = map["biography"]["full-name"],
        image = map["image"]["url"];
}
