import 'package:flutter/material.dart';
import 'package:superhero_flutter/models/hero.dart';
import 'package:superhero_flutter/services/hero_service.dart';
import 'package:superhero_flutter/widgets/custom_search_bar.dart';

class HeroListScreen extends StatefulWidget {
  const HeroListScreen({super.key});

  @override
  State<HeroListScreen> createState() => _HeroListScreenState();
}

class _HeroListScreenState extends State<HeroListScreen> {
  String query = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text("Super Hero"),
      ),
      body: Column(
        children: [
          CustomSearchBar(
            callback: (value) {
              setState(() {
                query = value;
              });
            },
          ),
          Expanded(child: HeroList(query: query)),
        ],
      ),
    );
  }
}

class HeroList extends StatefulWidget {
  const HeroList({super.key, required this.query});
  final String query;
  @override
  State<HeroList> createState() => _HeroListState();
}

class _HeroListState extends State<HeroList> {
  List _heros = [];
  final HeroService _heroService = HeroService();

  @override
  Widget build(BuildContext context) {
    if (widget.query.isEmpty) {
      return Container();
    }
    return FutureBuilder<List>(
      future: _heroService.searchHeros(widget.query),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
            child: CircularProgressIndicator(),
          );
        } else if (snapshot.hasError) {
          return const Center(
            child: Text("No se encontraron resultados"),
          );
        } else {
          _heros = snapshot.data ?? [];
          return ListView.builder(
            itemCount: _heros.length,
            itemBuilder: (context, index) {
              return HeroItem(hero: _heros[index]);
            },
          );
        }
      },
    );
  }
}

class HeroItem extends StatelessWidget {
  const HeroItem({super.key, required this.hero});
  final SuperHero hero;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Image.network(hero.image),
      title: Text(hero.name),
      subtitle: Text(hero.fullName),
    );
  }
}
