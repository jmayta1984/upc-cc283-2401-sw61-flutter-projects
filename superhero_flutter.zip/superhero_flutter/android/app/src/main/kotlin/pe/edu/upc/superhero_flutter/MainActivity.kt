package pe.edu.upc.superhero_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
